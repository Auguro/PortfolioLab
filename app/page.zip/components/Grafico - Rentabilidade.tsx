"use client";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface Ponto {
  data: string;
  valor: number;
}

interface ConfigSimulacao {
  dataInicio: string;
  dataFim: string;
}

interface Props {
  dados: {
    cdi: Ponto[] | null;
    paridade: Ponto[] | null;
    eficiente: Ponto[] | null;
  };
  config: ConfigSimulacao | null;
}

const ESTRATEGIAS_CONFIG = [
  { id: "cdi",      label: "CDI",               cor: "var(--amarelo)" },
  { id: "paridade", label: "Paridade de Risco",  cor: "var(--verde)"  },
  { id: "eficiente",label: "Carteira Eficiente", cor: "var(--azul)"   },
];

export default function Grafico({ dados, config }: Props) {

  // ---- CHART DATA ----
  const combined: Record<string, any> = {};

  ESTRATEGIAS_CONFIG.forEach(({ id }) => {
    const serie = dados[id as keyof typeof dados];
    if (serie) {
      serie.forEach((item) => {
        if (!combined[item.data]) combined[item.data] = { data: item.data };
        combined[item.data][id] = item.valor;
      });
    }
  });

  const chartData = Object.values(combined).sort((a, b) =>
    a.data.localeCompare(b.data)
  );

  // ffill
  const lastValues: Record<string, number | null> = { cdi: null, paridade: null, eficiente: null };
  chartData.forEach((item: any) => {
    ESTRATEGIAS_CONFIG.forEach(({ id }) => {
      if (item[id] !== undefined) lastValues[id] = item[id];
      else item[id] = lastValues[id];
    });
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "100%" }}>

      {/* GRÁFICO */}
      <div style={{ width: "100%", height: 400 }}>
        <ResponsiveContainer>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--borda)" />
            <XAxis dataKey="data" stroke="var(--texto-suave)" />
            <YAxis stroke="var(--texto-suave)" />
            <Tooltip
              contentStyle={{ background: "var(--fundo-card)", borderColor: "var(--borda)" }}
            />
            <Legend />
            {dados.cdi      && <Line type="monotone" dataKey="cdi"       stroke="var(--amarelo)" name="CDI"               dot={false} />}
            {dados.paridade && <Line type="monotone" dataKey="paridade"  stroke="var(--verde)"   name="Paridade de Risco" dot={false} />}
            {dados.eficiente && <Line type="monotone" dataKey="eficiente" stroke="var(--azul)"    name="Carteira Eficiente" dot={false} />}
          </LineChart>
        </ResponsiveContainer>
      </div>

    </div>
  );
}
